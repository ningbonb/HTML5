$(function() {
	//预加载图片
	var loadingImgs = ["img/add.png", "img/addbutton.png", "img/again.png", "img/background.jpg", "img/car.png", "img/close.png", "img/cloud1.png", "img/cloud2.png", "img/font1.png", "img/font2.png", "img/font3.png", "img/gamecar.png", "img/min.png", "img/rule.png", "img/share.png", "img/shareimg.png", "img/start.png", "img/trybutton.png"];
	//记录完成的张数
	var loadingNum = 0;
	//依次创建图片
	for(var i = 0; i < loadingImgs.length; i++) {
		var img = new Image();
		img.src = loadingImgs[i];
		img.onload = function() {
			//张数加1
			loadingNum++;
			//计算百分比
			var precent = Math.floor(loadingNum / loadingImgs.length * 100) + "%";
			//输出百分比
			$("#loading").html(precent);
			//判断加载是否完成
			if(loadingNum == loadingImgs.length) {
				//加载页面隐藏
				$("#loading-wrap").hide();
				//首页出现
				$("#page1").show();
			}
		}
	} //图片创建结束

	//点击开始按钮
	$("#start").click(function() {
		//首页隐藏
		$("#page1").hide();
		//游戏界面出现
		$("#page2").show();
		//游戏说明界面出现
		$("#page3").show();
	});

	//点击关闭按钮
	$(".close").click(function() {
		//游戏界面隐藏
		$("#page3").hide();
	});
	//点击屏幕关闭游戏说明
	$("#page3").click(function() {
		//游戏界面隐藏
		$("#page3").hide();
	});

	//游戏界面
	//汽车拖拽
	var isdrag = false;
	var NowLeft, disX;
	var NowTop, disY;
	var oDiv2 = document.getElementById("gamecar");
	var bug1 = document.getElementById("bug1");
	var bug2 = document.getElementById("bug2");
	var bug3 = document.getElementById("bug3");
	var bug4 = document.getElementById("bug4");
	var page2 = document.getElementById("page2");
	oDiv2.addEventListener('touchstart', thismousedown);
	oDiv2.addEventListener('touchend', thismouseup);
	oDiv2.addEventListener('touchmove', thismousemove);

	var ismove = false;
	function thismousedown(e) {
		//障碍物移动
		bugMove();
		//碰撞检测
		crashFn();
		isdrag = true;
		NowLeft = oDiv2.offsetLeft;
		NowTop = oDiv2.offsetTop;
		disX = e.touches[0].pageX;
		disY = e.touches[0].pageY;
		return false;
	}

	function thismousemove(e) {
		if(isdrag) {
			oDiv2.style.left = NowLeft + e.touches[0].pageX - disX + 'px';
			oDiv2.style.top = NowTop + e.touches[0].pageY - disY + 'px';
			return false;
		}
		
	}

	function thismouseup() {
		isdrag = false;
	};
	
	//碰撞检测定时器
	var timer2;
	function crashFn(){
		timer2 = setInterval(function(){
			//碰撞检测
			if(oDiv2.offsetLeft <= 0 || oDiv2.offsetLeft + oDiv2.offsetWidth >= page2.offsetWidth || oDiv2.offsetTop <= 0 || oDiv2.offsetTop + oDiv2.offsetHeight >= page2.offsetHeight){
				gameover();
			}
			if(crash(oDiv2,bug1)||crash(oDiv2,bug2)||crash(oDiv2,bug3)||crash(oDiv2,bug4)){
				gameover();
			}
		},10);
	}
	
	
	//碰撞函数
	function crash(obj1, obj2) {
		//碰撞检测
		var L1 = obj1.offsetLeft;
		var R1 = L1 + obj1.offsetWidth;
		var T1 = obj1.offsetTop;
		var B1 = T1 + obj1.offsetHeight;

		var L2 = obj2.offsetLeft;
		var R2 = L2 + obj2.offsetWidth;
		var T2 = obj2.offsetTop;
		var B2 = T2 + obj2.offsetHeight;

		//没有碰撞的时候
		if(R1 < L2 || B1 < T2 || L1 > R2 || T1 > B2) {
			//碰不到
			return false;
		} else {
			return true;
		}
	}
	
	//游戏结束
	function gameover(){
		$("#page2").hide();
		$("#page4").show();
		$("#end_min").html(Math.floor(getTime/1000));
		clearInterval(timer);
		clearInterval(timer2);
		$("#bug1").css({
			"top": "22%",
			"left": "55%"
		});
		$("#bug2").css({
			"top": "40%",
			"left": "10%"
		});
		$("#bug3").css({
			"top": "41%",
			"left": "75%"
		});
		$("#bug4").css({
			"top": "61%",
			"left": "31%"
		});
		$("#gamecar").css({
			"top": "40%",
			"left": "45%"
		});
	}
	
	//游戏结束页面
	//分享页面
	$("#share").click(function(){
		$("#page5").show();
	});
	//点击屏幕关闭分享页面出现抽奖
	$("#page5").click(function() {
		//游戏界面隐藏
		$("#page4").hide();
		$("#page5").hide();
		$("#page7").show();
	});
	//重玩一次
	$("#again").click(function(){
		$("#page4").hide();
		$("#page2").show();
		getTime = 0;
		$("#min").html("0");
		$("#sed").html("0");
	});
	
	//关注按钮
	$("#addbutton").click(function(){
		$("#page6").show();
	});
	//点击屏幕关闭关注页面
	$("#page6").click(function(){
		$("#page6").hide();
	});
	
	//我要试驾按钮
	$("#trybutton").click(function(){
		$("#page7").hide();
		$("#page4").show();
	});
	//障碍物移动
	var timer;
	var getTime = 0;
	var speedX = 0.3;
	var speedY = 0.3;
	var speedX2 = -0.2;
	var speedY2 = 0.3;
	var speedX3 = 0.2;
	var speedY3 = -0.3;
	var speedX4 = -0.3;
	var speedY4 = -0.3;
	function bugMove(){
		
		clearInterval(timer);
		timer = setInterval(function(){
			bug1.style.left = parseFloat(bug1.style.left) + speedX + "%";
			bug1.style.top = parseFloat(bug1.style.top) + speedY + "%";
			if(parseFloat(bug1.style.left)<=0 || parseFloat(bug1.style.left)+parseFloat(bug1.style.width) >= 100){
				speedX = -speedX;
			}
			if(parseFloat(bug1.style.top)<=0 || parseFloat(bug1.style.top)+parseFloat(bug1.style.height) >= 100){
				speedY = -speedY;
			}
			
			bug2.style.left = parseFloat(bug2.style.left) + speedX2 + "%";
			bug2.style.top = parseFloat(bug2.style.top) + speedY2 + "%";
			if(parseFloat(bug2.style.left)<=0 || parseFloat(bug2.style.left)+parseFloat(bug2.style.width) >= 100){
				speedX2 = -speedX2;
			}
			if(parseFloat(bug2.style.top)<=0 || parseFloat(bug2.style.top)+parseFloat(bug2.style.height) >= 100){
				speedY2 = -speedY2;
			}
			
			bug3.style.left = parseFloat(bug3.style.left) + speedX3 + "%";
			bug3.style.top = parseFloat(bug3.style.top) + speedY3 + "%";
			if(parseFloat(bug3.style.left)<=0 || parseFloat(bug3.style.left)+parseFloat(bug3.style.width) >= 100){
				speedX3 = -speedX3;
			}
			if(parseFloat(bug3.style.top)<=0 || parseFloat(bug3.style.top)+parseFloat(bug3.style.height) >= 100){
				speedY3 = -speedY3;
			}
			
			bug4.style.left = parseFloat(bug4.style.left) + speedX4 + "%";
			bug4.style.top = parseFloat(bug4.style.top) + speedY4 + "%";
			if(parseFloat(bug4.style.left)<=0 || parseFloat(bug4.style.left)+parseFloat(bug4.style.width) >= 100){
				speedX4 = -speedX4;
			}
			if(parseFloat(bug4.style.top)<=0 || parseFloat(bug4.style.top)+parseFloat(bug4.style.height) >= 100){
				speedY4 = -speedY4;
			}
			getTime += 16;
			$("#min").html(Math.floor(getTime/1000));
			$("#sed").html(Math.floor(getTime%1000/16.7));
		},16);
	}
		
}); //jQuery结束
//元素加载完成(不需要等待资源加载完成, 如果需要检测资源加载完成, 使用window.onload)
$(function(){
	//预加载图片
	var loadingImgs = ["img/activity_rule.png", "img/bg.jpg", "img/bg2.png", "img/close.png", "img/p1_btns_wrap.png", "img/p1_first.png", "img/p1_from.png", "img/p1_second.png", "img/p1_sub.png", "img/p1_third.png", "img/p2_kuang.png", "img/p2_qian.jpg", "img/p2_scoring.png", "img/p2_shou.png", "img/p2_txt1.png", "img/p2_txt2.png", "img/p2_txt3.png", "img/p2_zhuan.png", "img/p3_acquire.png", "img/p3_again.png", "img/p3_bg.jpg", "img/p3_share.png", "img/p3_share_btn.png", "img/prize.png", "img/qian.png", "img/ranking.png", "img/ranking_bg.png", "img/shiyong.png", "img/shizhong.png", "img/shou.png", "img/start_game.png", "img/tiaozhan.png", "img/yingqu.png"];
	//记录完成的张数
	var loadingNum = 0;
	//依次创建图片
	for(var i = 0; i < loadingImgs.length; i++) {
		//var img = document.createElement("img");
		var img = new Image();
		img.src = loadingImgs[i];
		img.onload = function() {
			//张数加1
			loadingNum++;
			//计算百分比
			var precent = Math.floor(loadingNum / loadingImgs.length * 100) + "%";
			//显示百分比
			$("#loading").html(precent);
			//判断是否加载完成
			if(loadingNum == loadingImgs.length) {
				$("#loading-wrap").hide();
				//进入第一页(默认隐藏)
				$("#page1").show();
			}
		}
	}//图片创建结束

	//点击开始按钮
	$("#start").click(function(){
		$("#user-alert").slideDown();
	});
	//所有弹出层的关闭按钮
	$(".close").click(function(){
		$(".alert-wrap").slideUp();
	});

	//点击数钱榜
	$(".rank1").click(function(){
		//查询数据库通过ajax请求
		$("#rank-alert").show();
	});

	//活动规则
	$(".rule").click(function(){
		$("#rule-alert").fadeIn();
	});

	//活动奖品
	$(".prize").click(function(){
		$("#prize-alert").show();
	});

	//使用说明
	$(".explain").click(function(){
		$("#explain-alert").show();
	});

	//提交信息开始游戏
	$("#user-form>input[type=button]").click(function(){
		$("#user-alert").hide();
		$("#page1").hide();
		//页面2显示
		$("#page2").show();
		//加载页面2js
		enterP2();
	});

	//页面2的js
	function enterP2(){
		//记录文字图片数组读的下标
		var index = 0;
		var textImgs = ["img/p2_txt1.png","img/p2_txt2.png","img/p2_txt3.png"];
		var textTimer = setInterval(function(){
			index++;
			if(index == 4) index = 0;
			$("#text").prop("src",textImgs[index]);
		},1500);

		//禁止掉页面的上下滚动
		touch.on("#page2","touchstart",function(event){
			event.preventDefault();
		});
		
		//通过定时器的值判断游戏是否开始
		var countDownTime;//undefined没有开始
		//开始触摸
		touch.on("#money-wrap", "touchstart", function(event) {
			//倒计时计时
			countDownTimeFn();
		});
		window.countDownTimeFn = function(){
					//没有开始, 可以创建计时器,之后在点击定时器不会被创建了
			if(countDownTime == undefined) {
					//游戏的总时间
					var allTime = 5;
					countDownTime = setInterval(function() {
					allTime--;
					$(".time-clock").html(allTime);
					//判断游戏是否结束
					if (allTime == 0) {
						//游戏结束
						clearInterval(countDownTime);
						//保证下次判断可以进来
						countDownTime = undefined;
						//进入第三页
						$("#page2").hide();
						$("#page3").show();
						//页面3布局，并且传入总的钱数
						enterPage3(window.moneyCount);
					}
				}, 1000);
			}
		}
		//记录数钱的数量
		window.moneyCount = 0;
		//向上滑动
		touch.on("#money-wrap", "swipeup", function () {
			//修改数字
			moneyCount++;
			var score_str = ("00" + moneyCount).substr(-3);
			$(".time-num").eq(0).html(score_str[0]);
			$(".time-num").eq(1).html(score_str[1]);
			$(".time-num").eq(2).html(score_str[2]);
			
			//钱向上飞
			var moneyImg = $('<img src="img/p2_qian.jpg" id="money">');
			//插入到以前地方
			$("#money-wrap").append(moneyImg);
			//起飞
			moneyImg.addClass("fly");
			//钱飞走后移除
			 setTimeout(function () {
			 	moneyImg.remove();
			 }, 1000);
		});


	}//页面2js函数结束

	//页面3
	function enterPage3(moneyCount) {
		//***获取到用户名，id等，把上传得分
		//uploadScore(moneyCount);
		//显示最终成绩
		$("#result-money").html("￥" + moneyCount);

		//点击再来一次
		$("#again").click(function() {
			$("#page3").hide();
			$("#page2").show();
			//enterPage2();
			$(".time-num").html("0");
			$(".time-clock").html("60");
			//重新计时
			window.countDownTimeFn();
			window.moneyCount = 0;

		});
		//点击分享
		// $("#share").click(function() {
		// 	$("#share-alert").show();
		// });
		// //隐藏分享
		// $("#share-alert").click(function() {
		// 	$(this).hide();
		// });
	}//页面3结束

});
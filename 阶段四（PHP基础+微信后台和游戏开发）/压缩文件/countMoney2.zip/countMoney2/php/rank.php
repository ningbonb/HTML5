<?php 
	// 等级查询php
	require "SQL.php";
	//对数据库进行查询, 按照分数降序排序, 取5条
	$sql = "SELECT * FROM user ORDER BY score DESC limit 5";
	//查询
	selectData($sql,function($jsonStr){

	},function(){

	});




 ?>
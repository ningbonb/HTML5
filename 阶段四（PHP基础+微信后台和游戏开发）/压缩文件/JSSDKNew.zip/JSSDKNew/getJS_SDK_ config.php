<?php 
	// 参数是需要使用js_sdk的网页
	require "jssdk.php";
	//获取参数
	$url = $_GET["url"];
	//获取jssdk对象
	$jssdk = new JSSDK("wx6ae3aaab84b1d282","a64b851781ffb77cf97d7b0b05dce45c",$url);
	//信息配置
	$infoArr = $jssdk->getSignPackage();
	//返回信息
	echo json_encode($infoArr);


 ?>